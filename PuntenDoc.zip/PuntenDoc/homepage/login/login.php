<?php
session_start();
  // skrip koneksi
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="../images/puntendoc/logopuntendoc.png" type="image/x-icon" />
  <link rel="stylesheet" href="style.css">
  <title>Sign In</title>
</head>
<body>
  <h2>PUNTENDOC HEALTH IS PRIORITY, PLEASE SIGN IN</h2>
  <div class="container" id="container">
    <div class="form-container sign-up-container">
      <form method="post">
        <h1>Create Account</h1>
        <input type="text" name="fullname" placeholder="Full Name" required/>
        <input type="email" name="username" placeholder="Email" required/>
        <input type="password" name="password" placeholder="Password" required/>
        <input type="tel" name="notelp" placeholder="Phone Number" required >
        <a href="login.php"><button name="daftar">Sign Up</button></a>
      </form>
    </div>
    <?php 
    if (isset($_POST["daftar"])) {
      $namalengkap = $_POST['fullname'];
      $email = $_POST['username'];
      $password = $_POST['password'];
      $notelp = $_POST['notelp'];

      $ambil = $koneksi->query("SELECT * FROM dataclient WHERE email='$email'");
      $yangcocok = $ambil->num_rows;
      if($yangcocok == 1) {
        $akun = $ambil->fetch_assoc();
        $_SESSION['daftar'] = $akun;
        echo "<script>alert('Pendaftaran Gagal, email sudah digunakan');</script>";
        echo "<script>location='login.php';</script>";
      } else {
        $koneksi->query("INSERT INTO dataclient (id_client, namalengkap, email, password, notelp) VALUES ('', '$namalengkap', '$email', '$password', '$notelp')");
      }
    }
    ?>
    <div class="form-container sign-in-container">
      <form role="form" method="post">
        <h1>Sign in</h1>
        <div class="social-container">
        </div>
        <input type="email" name="loginemail" placeholder="Email" />
        <input type="password" name="loginpass" placeholder="Password" />
        <button name="login">Sign In</button>
      </form>
      <?php 
      if (isset($_POST['login'])) {
        $email = $_POST['loginemail'];
        $password = $_POST['loginpass'];
        $ambil = $koneksi->query("SELECT * FROM dataclient WHERE email='$email' AND password='$password'");
        $akunyangcocok = $ambil->num_rows;
        if ($akunyangcocok == 1) {
          $akun = $ambil->fetch_assoc();
          $_SESSION["pelanggan"] = $akun;
          echo "<script>alert('Sukses Login');</script>";
          echo "<script>location='../checkout.php';</script>";
        } else {
          echo "<script>alert('Gagal Login');</script>";
          echo "<script>location='login.php';</script>";
        }
      }
      ?>
    </div>
    <div class="overlay-container">
      <div class="overlay">
        <div class="overlay-panel overlay-left">
          <h1>Welcome Back!</h1>
          <p>To connect with us, please login with your personal info</p>
          <button class="ghost" id="signIn">Sign In</button>
        </div>
        <div class="overlay-panel overlay-right">
          <h1>Hello, Sob!</h1>
          <p>Enter your personal details and start journey with us</p>
          <button class="ghost" id="signUp">Sign Up</button>
        </div>
      </div>
    </div>
  </div>
  <footer>
    <p>
      Created with <i class="fa fa-heart"></i> by
      <a target="_blank" href="https://www.instagram.com/dzikrashf/">Dzikramuh</a>
      - Follow my Instagram and start journey with us
      <a target="_blank" href="https://trisakti.ac.id/">here</a>.
    </p>
  </footer>
  <script src="script.js"></script>
</body>
</html>