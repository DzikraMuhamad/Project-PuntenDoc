<?php 
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/profile/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="css/profile/theme-default.css" class="template-customizer-core-css" />
    <title>Document</title>
</head>
<body>
    <div class="col-lg-11 mb-4 order-0" style="margin: auto;">
        <div class="card">
            <div class="d-flex align-items-end row">
                <div class="">
                    <div class="card-body">
                        <h5 class="card-title text-primary">Edit My Profile</h5>
                        <?php
                        $ambil = $koneksi->query("SELECT * FROM dataclient");
                        $pecah = $ambil->fetch_assoc();
                        ?>
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="">Fullname</label>
                                <input type="text" class="form-control" name="fullname" value="<?php echo $pecah['namalengkap'];?>">
                            </div>
                            <div class="form-group">
                                <label for="">NIK</label>
                                <input type="number" class="form-control" name="nik" value="<?php echo $pecah['nik'];?>">
                            </div>
                            <div class="form-group">
                                <label for="">Gender</label>
                                <input type="text" class="form-control" name="gender" value="<?php echo $pecah['jkelamin'];?>">
                            </div>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="text" class="form-control" name="email" value="<?php echo $pecah['email'];?>">
                            </div>
                            <div class="form-group">
                                <label for="">Phone Number</label>
                                <input type="number" class="form-control" name="notelp" value="<?php echo $pecah['notelp'];?>">
                            </div>
                            <div class="form-group">
                                <label for="">Address</label>
                                <input type="text" class="form-control" name="alamat" value="<?php echo $pecah['alamat'];?>">
                            </div>
                            <div class="form_group">
                                <img src="img/<?php echo $pecah['foto'];?>" width="100">
                            </div>
                            <div class="form-group">
                                <label>Change Photo</label>
                                <input type="file" name="foto" class="form-control">
                            </div>
                            <button class="btn btn-primary" name="change">Change</button>
                        </form>
                        <?php 
                        if (isset($_POST['change'])) {
                            $namafoto = $_FILES['foto']['name'];
                            $lokasifoto = $_FILES['foto']['tmp_name'];
                            // jika foto di rubah
                            if (!empty($lokasifoto)) {
                                move_uploaded_file($lokasifoto, "img/$namafoto");
                                $koneksi->query("UPDATE dataclient SET namalengkap='$_POST[fullname]', nik='$_POST[nik]', 
                                jkelamin='$_POST[gender]', email='$_POST[email]', notelp='$_POST[notelp]', 
                                alamat='$_POST[alamat]', foto='$namafoto' WHERE id_client='$_GET[id]'");
                            } else {
                                $koneksi->query("UPDATE dataclient SET namalengkap='$_POST[fullname]', nik='$_POST[nik]', 
                                jkelamin='$_POST[gender]', email='$_POST[email]', notelp='$_POST[notelp]', 
                                alamat='$_POST[alamat]' WHERE id_client='$_GET[id]'");
                            }
                            echo "<script>alert('Data telah diubah');</script>";
                            echo "<script>location='myprofile.php';</script>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
