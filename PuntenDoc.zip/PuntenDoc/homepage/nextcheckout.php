<h1>hai</h1>
<?php 
echo $id_pelanggan;
echo $tanggan_pembelian;
echo $total_pelanggan;
?>