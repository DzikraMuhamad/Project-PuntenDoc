<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");

if (!isset($_SESSION['pelanggan'])) {
    echo "<script>alert('Silahkan Login');</script>";
    echo "<script>location='login/login.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="stylebaru.css">
    <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <div class="navbar">
        <li class="list-item"><i class="fa-solid fa-house"></i>
            <span class="list-item-name">Home</span>
        </li>
        <li class="list-item">
            <i class="fa-solid fa-user"></i>
            <span class="list-item-name">Profile</span>
        </li>
        <li class="list-item">
            <i class="fa-solid fa-gear"></i>
            <span class="list-item-name">Settings</span>
        </li>
        <li class="list-item">
            <i class="fa-solid fa-bag-shopping"></i>
            <span class="list-item-name">Bag</span>
        </li>
    </div>
    <div class="col-sm-6">
        <main id="main">
            <?php $ambil = $koneksi->query("SELECT * FROM datadoctor"); ?>
            <?php while($perproduk = $ambil->fetch_assoc()){ ?>
            <div class="card"><img src="../../imgdoc/<?php echo $perproduk['foto']; ?>" alt=""/>
                <div class="text">
                <h2 data-splitting=""><?php echo $perproduk['fullname']; ?></h2>
                <p data-splitting=""><?php echo $perproduk['spcdokter']; ?> . <?php echo $perproduk['jkelamin']; ?></p>
                <p data-splitting=""><?php echo $perproduk['email']; ?> . <?php echo $perproduk['notelp']; ?></p>
                <form method="post"><a href="ChatApp/index.php&id=<?php echo $perproduk['id_doctor']; ?>"><button name="chat"><i class="fa-regular fa-comment-dots fa-2x"></i></button></a></form>
                </div>
            </div>
            <?php $id = $perproduk['id_doctor']; ?>
            <?php } ?>
        </main>
    </div>
    <?php 
    if(isset($_POST["chat"])){
        $id_pelanggan = $_SESSION["pelanggan"]["id_client"];
        $id_doctor = $id;
        $tanggal_pembelian = date("Y-m-d");
        $pesan = $_SESSION["pelanggan"]["namalengkap"];
        $koneksi->query("INSERT INTO orderan (id_doctor, id_client, tanggal, pesan) VALUES('$id_doctor', '$id_pelanggan', '$tanggal_pembelian', '$pesan')");

        $ambillagi = $koneksi->query("SELECT * FROM datadoctor WHERE id_doctor='$id_doctor'");
        $pecahlagi = $ambillagi->fetch_assoc();

        $koneksi->query("INSERT INTO pesan (pesan, id_doctor) VALUES ('$pesan', '$id_doctor')");

        echo "<script>alert('Thank You, Enjoy Your Consultation');</script>";
        echo "<script>location='../../ChatApp/login.php';</script>";
        }  
    ?>
    <!-- <pre>
        <?php print_r($_SESSION['pelanggan']); ?>
    </pre> -->
    
</body>
</html>