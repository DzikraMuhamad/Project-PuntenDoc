<?php
session_start();
session_destroy();
echo "<script>alert('Paket Dihapus');</script>";
echo "<script>location='index.php#price';</script>";
?>