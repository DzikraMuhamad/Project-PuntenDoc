<?php 
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/profile/style.css">
    <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <aside class="profile-card">
        <header>
            <!-- here’s the avatar -->
            <a target="_blank" href="#">
            <img src="img/<?php echo $_SESSION['pelanggan']['foto']?>" class="hoverZoomLink">
            </a>
            <!-- the username -->
            <h1><?php echo $_SESSION['pelanggan']['namalengkap']?></h1>
            <!-- and role or location -->
            <h2><?php echo $_SESSION['pelanggan']['nik']?></h2>
            <h3><?php echo $_SESSION['pelanggan']['jkelamin']?></h3>
        </header>
        <!-- bit of a bio; who are you? -->
        <div class="profile-bio">
        <p><?php echo $_SESSION['pelanggan']['email']?></p>
        <p><?php echo $_SESSION['pelanggan']['notelp']?></p>
        <p><?php echo $_SESSION['pelanggan']['alamat']?></p>
        </div>
        <!-- some social links to show off -->
        <ul class="profile-social-links">
            <li>
            <a href="checkout.php">
                <i class="fa-solid fa-left-long"></i>
            </a>
            </li>
            <li>
            <a href="editprofile.php">
                <i class="fa-solid fa-paintbrush"></i>
            </a>
            </li>
        </ul>
        </aside>
</body>
</html>