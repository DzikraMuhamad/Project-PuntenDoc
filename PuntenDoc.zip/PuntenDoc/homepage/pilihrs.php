<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
if (!isset($_SESSION['pelanggan'])) {
    echo "<script>alert('Silahkan Login');</script>";
    echo "<script>location='login/login.php';</script>";
}
// echo "<pre>";
// print_r($_SESSION['pelanggan']);
// echo "</pre>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css">
  <link rel="stylesheet" href="css/viewmoredoctor/style.css">
  <link rel="stylesheet" href="css/viewmoredoctor/style1.css">
  <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
  <link rel="shortcut icon" href="../homepage/images/puntendoc/logopuntendoc.png" type="image/x-icon" />
  <!-- <script src="js/viwemoredoctor/jss.js"></script> -->
  <title>View More Doctor</title>
</head>
<body>
    <header>
         
        
        <div class="company-logo"><img src="../homepage/images/puntendoc/PuntenDocwteks1.png" alt=""></div>
        <nav class="navbar">
        <ul class="nav-items">
            <li class="nav-item"><a href="index.php" class="nav-link">HOME</a></li>
            <li class="nav-item"><a href="#" class="nav-link">OFFER</a></li>
            <li class="nav-item"><a href="#" class="nav-link">SHOP</a></li>
            <li class="nav-item"><a href="#" class="nav-link">CONTACT</a></li>
        </ul>
        </nav>
        <div class="menu-toggle">
        <i class="bx bx-menu"></i>
        <i class="bx bx-x"></i>
        </div>
    </header>
    <div class="heading1">
        <span class="icon-logo1"><img src="images/puntendoc/logopuntendoc.png" alt="#"></span>
        <h2>Our Hospitals Collaboration</h2>
    </div>
    <section>
        <div class="container-fluid">
        <div class="container">
            <div class="row">
            <?php $ambil = $koneksi->query("SELECT * FROM datarumahsakit"); ?>
            <?php while($perproduk = $ambil->fetch_assoc()){ ?>
            <div class="col-sm-4">
                <div class="card">
                <div class="post-image">
                    <img src="../imgrs/<?php echo $perproduk['foto']; ?>" class="img-responsive">
                </div>
                <div class="news-content">
                    <span class="category"><?php echo $perproduk['nama']; ?></span>
                    <div class="post-meta">
                    <span class="author"><a href="selectrs.php&id=<?php echo $perproduk['id_rumahsakit']; ?>">
                        <i class="fa-solid fa-user" aria-hidden="true"></i>Select
                    </a></span>
                    <span class="time"><a href="#">
                        <i class="fa fa-clock-o" aria-hidden="true"></i>Dec 2022
                    </a></span>
                    <span class="comment"><a href="#">
                        <i class="fa-solid fa-comment" aria-hidden="true"></i>Someone Famous
                    </a></span>
                    <div class="clearfix"></div>
                    </div>
                    <h2 class="post-header">
                    <?php echo $perproduk['email']; ?>
                    </h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo, sit.</p>
                    <form method="post">
                    <a href="index.php?id=<?php echo $perproduk['id_rumahsakit']; ?>"><button class="btn btn-primary" name="select">Select</button></a>
                    </form>
                </div>
                </div>
            </div>
            <?php 
                if(isset($_POST["select"])){
                $id_client = $_SESSION['pelanggan']['id_client'];
                $namalengkap = $_SESSION['pelanggan']['namalengkap'];
                $id_rumahsakit = $perproduk['id_rumahsakit'];
                $namars = $perproduk['nama'];

                    $koneksi->query("INSERT INTO dataregis (id_client, namalengkap, id_rumahsakit, namars) VALUES ('$id_client', '$namalengkap', '$id_rumahsakit', '$namars')");
                    echo "<script>alert('Success select hospital');</script>";
                    echo "<script>location='index.php';</script>";
                }  
                ?>
            <?php } ?>
            </div>
            
            
        </div>
        </div>
    </section>
  
</body>
</html>