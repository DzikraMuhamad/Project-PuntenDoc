<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");

if (!isset($_SESSION['pelanggan'])) {
    echo "<script>alert('Silahkan Login');</script>";
    echo "<script>location='login/login.php';</script>";
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/puntendoc/logopuntendoc.png" type="image/x-icon" />
    <link rel="stylesheet" href="assets/css/cekout.css">
    <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
        rel="stylesheet">
    <title>Cart</title>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div class="logo"></div>
            <ul>
            <li><a>
                <div class="icon material-icons"></div><span>PuntenDoc</span>
                </a></li>
            <li>
                <hr>
            </li>
            </ul>
            <ul>
            <li><a>
                <div class="icon material-icons">dashboard</div><span>Dashboard</span>
                </a></li>
            <li class="active">
                <a>
                <div class="icon material-icons">local_library</div><span>Library</span>
                </a>
                <ul class="sub-items">
                <li><a><span>Doctors</span></a></li>
                <li><a><span>Hospitals</span></a></li>
                <li><a><span>Result</span></a></li>
                </ul>
            </li>
            <li><a>
                <div class="icon material-icons">local_activity</div><span>Experience</span>
                </a></li>
            <li><a>
                <div class="icon material-icons">checkout</div><span>Check Out</span>
                </a></li>
            </ul>
            <ul class="fixed">
            <li>
                <hr>
            </li>
            <li><a href="myprofile.php">
                <div class="icon material-icons">face</div><span>My Profile</span>
                </a></li>
            <li><a>
                <div class="icon material-icons">notifications</div><span>Notifications</span>
                </a></li>
            <li><a>
                <div class="icon material-icons">settings</div><span>Setting</span>
                </a></li>
            <li><a>
                <div class="icon material-icons">info</div><span>Know how</span>
                </a></li>
            <?php if (isset($_SESSION['pelanggan'])) : ?>
                <li><a href="login/logout.php">
                    <div class="icon material-icons">logout</div><span>Log Out</span>
                </a></li>
            <?php else: ?>
                <li><a href="login/login.php">
                    <div class="icon material-icons">login</div><span>Log In</span>
                </a></li>
            <?php endif ?>
            </ul>
        </div>
        <div class="row">
            <div class="column">
                <!-- <div class="page"> -->
                <h1>Detail Packet</h1>
                <div class="detail">
                        <hr>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID Packet</th>
                                    <th>Packet</th>
                                    <th>Price</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody> 
                                <?php $nomor = 1; ?>
                                <?php $totalbelanja = 0; ?>
                                <?php foreach ($_SESSION['keranjang'] as $id_produk => $jumlah): ?>
                                <?php $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk = '$id_produk'");
                                    $pecah = $ambil->fetch_assoc();
                                    $subharga = $pecah["price"] * $jumlah;
                                ?>
                                <tr>
                                    <td><?php echo $pecah['id_produk']; ?></td>
                                    <td><?php echo $pecah['nama']; ?></td>
                                    <td>Rp. <?php echo number_format($subharga); ?></td>
                                    <td><?php echo $jumlah ?></td>
                                </tr>
                                <?php $nomor++; ?>
                                <?php $totalbelanja += $subharga; ?>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                        <hr>
                        <?php $nomor = 1; ?>
                        <h3>Service Product</h3>
                        <p><?php echo $pecah['nama']; ?></p>
                        <p><?php echo $pecah['chat']; ?></p>
                        <p><?php echo $pecah['respons']; ?></p>
                        <p><?php echo $pecah['saved']; ?></p>
                        <p><?php echo $pecah['time']; ?></p>
                        <p><?php echo $pecah['best']; ?></p>
                        <p><?php echo $pecah['freeregis']; ?></p>
                        <a href="batal.php"><button class="btn">Delete</button></a>
                        <form method="post"><button name="checkout">Checkout</button></form>
                </div>
                <?php 
                if(isset($_POST["checkout"])){
                    $id_pelanggan = $_SESSION["pelanggan"]["id_client"];
                    $tanggal_pembelian = date("Y-m-d");
                    $total_pembelian = $subharga;
                    $koneksi->query("INSERT INTO datapembayaran (id_pelanggan, tanggal_pembelian, total_pembelian) VALUES('$id_pelanggan', '$tanggal_pembelian', '$total_pembelian')");
                    // mendapatkan id_pembelian
                    $id_pembelian_barusan = $koneksi->insert_id;
                    foreach ($_SESSION["keranjang"] as $id_produk => $jumlah) {
                        $koneksi->query("INSERT INTO pembelianpaket (id_pembelian, id_produk, jumlah) VALUES ('$id_pembelian_barusan', '$id_produk', '$jumlah')");
                    }
                    // mengosongkan keranjang
                    unset($_SESSION["keranjang"]);
                    
                    echo "<script>alert('Berhasil Checkout');</script>";
                    echo "<script>location='card/index.php';</script>";
                }  
                ?>
            </div>
        </div>
            <div class="column">
                <div class="konten">
                    <div class="card">
                        <div class="head-card">
                        <img src="images/puntendoc/PuntenDocwteks1.png" alt="">
                        </div>
                        <div class="body-card">
                        <h1><?php echo $_SESSION['pelanggan']['namalengkap']?></h1>
                        <p><?php echo $_SESSION['pelanggan']['nik']?></p>
                        <p><?php echo $_SESSION['pelanggan']['email']?></p>
                        <p><?php echo $_SESSION['pelanggan']['notelp']?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
