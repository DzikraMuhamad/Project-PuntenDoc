<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
?>


<!DOCTYPE html>
<html lang="en">
   <!-- Basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- Mobile Metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- Site Metas -->
   <title>PuntenDoc</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- Site Icons -->
   <link rel="shortcut icon" href="images/puntendoc/logopuntendoc.png" type="image/x-icon" />
   <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
   <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- Site CSS -->
   <link rel="stylesheet" href="style.css">
   <!-- Colors CSS -->
   <link rel="stylesheet" href="css/colors.css">
   <!-- ALL VERSION CSS -->
   <link rel="stylesheet" href="css/versions.css">
   <!-- Responsive CSS -->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- Custom CSS -->
   <link rel="stylesheet" href="css/custom.css">
   <!-- font awesome -->
   <link rel="stylesheet" href="css/font-awesome.min.css"/>
   <!-- Modernizer for Portfolio -->
   <script src="js/modernizer.js"></script>
   <!-- [if lt IE 9] -->
   <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
   </head>
   <body class="clinic_version">
      <!-- LOADER -->
      <div id="preloader">
         <img class="preloader" src="images/loaders/heart-loading2.gif" alt="">
      </div>
      <!-- END LOADER -->
      <header>
         <div class="header-top wow fadeIn">
            <div class="container">
               <a class="navbar-brand" href="index.html"><img src="images/puntendoc/PuntenDocwteks1.png" alt="image"></a>
               <!-- <div class="right-header">
                  <div class="header-info">
                     <div class="info-inner">
                        <span class="icontop"><img src="images/phone-icon.png" alt="#"></span>
                        <span class="iconcont"><a href="tel:800 123 456">800 123 456</a></span>	
                     </div>
                     <div class="info-inner">
                        <span class="icontop"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                        <span class="iconcont"><a data-scroll href="mailto:info@yoursite.com">info@Lifecare.com</a></span>	
                     </div>
                     <div class="info-inner">
                        <span class="icontop"><i class="fa fa-clock-o" aria-hidden="true"></i></span>
                        <span class="iconcont"><a data-scroll href="#">Daily: 7:00am - 8:00pm</a></span>	
                     </div>
                  </div>
               </div> -->
            </div>
         </div>
         <div class="header-bottom wow fadeIn">
            <div class="container">
               <nav class="main-menu">
                  <div class="navbar-header">
                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i class="fa fa-bars" aria-hidden="true"></i></button>
                  </div>
				  
                  <div id="navbar" class="navbar-collapse collapse">
                     <ul class="nav navbar-nav">
                        <li><a class="active" href="index.html">Home</a></li>
                        <li><a data-scroll href="#about">About us</a></li>
                        <li><a data-scroll href="#service">Services</a></li>
                        <li><a data-scroll href="#doctors">Doctors</a></li>
                        <li><a data-scroll href="#hospitals">Hospitals</a></li>
                        <li><a data-scroll href="#price">Price</a></li>
						<li><a data-scroll href="#testimonials">Testimonials</a></li>
                        <li><a data-scroll href="#getintouch">Contact</a></li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </header>
      <div id="home" class="parallax first-section wow fadeIn" data-stellar-background-ratio="0.4" style="background-image:url('images/slider-bg.png');">
         <div class="container">
            <div class="row">
               <div class="col-md-12 col-sm-12">
                  <div class="text-contant">
                     <h2>
                        <span class="center"><span class="icon"><img src="images/puntendoc/logopuntendoc.png" alt="#" /></span></span>
                        <a href="" class="typewrite" data-period="2000" data-type='[ "Welcome to PuntenDoc", "We Care Your Health", "We are Expert!" ]'>
                        <span class="wrap"></span>
                        </a>
                     </h2>
                  </div>
               </div>
            </div>
            <!-- end row -->
         </div>
         <!-- end container -->
      </div>
      <!-- end section -->
      <div id="time-table" class="time-table-section">
         <div class="container">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
               <div class="row">
                  <div class="service-time one" style="background:#2895f1;">
                     <span class="info-icon"><i class="fa fa-wechat" aria-hidden="true"></i></span>
                     <h3>Get Fastest Chat</h3>
                     <p>Mendapatkan fast respon dari dokter unggulan.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
               <div class="row">
                  <div class="service-time middle" style="background:#0071d1;">
                     <span class="info-icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> 
                     <h3>Working Hours</h3>
                     <div class="time-table-section">
                        <ul>
                           <li><span class="left">Monday - Friday</span><span class="right">8.00 – 18.00</span></li>
                           <li><span class="left">Saturday</span><span class="right">8.00 – 16.00</span></li>
                           <li><span class="left">Sunday</span><span class="right">8.00 – 13.00</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
               <div class="row">
                  <div class="service-time three" style="background:#0060b1;">
                     <span class="info-icon"><i class="fa fa-hospital-o" aria-hidden="true"></i></span>
                     <h3>Registration Hospital</h3>
                     <p>PuntenDoc dapat membuat appointment rumah sakit pasien secara otomatis dan mudah.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="about" class="section wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/puntendoc/logopuntendoc.png" alt="#"></span>
               <h2>Why You Should Choose Us</h2>
            </div>
            <!-- end title -->
            <div class="row">
               <div class="col-md-6">
                  <div class="message-box">
                     <h4>What We Do</h4>
                     <h2>PuntenDoc Service</h2>
                     <p class="lead">Public health has an important role in efforts to improve the quality of human resources, poverty alleviation, and economic development. The Human Development Index places health as one of the main components of measurement besides education and income.</p>
                     <p> Integrate health services from all hospitals or clinics so that the wider community can receive doctors' responses and get treatment quickly and efficiently.</p>
                     <a href="#services" data-scroll class="btn btn-light btn-radius btn-brd grd1 effect-1">Learn More</a>
                  </div>
                  <!-- end messagebox -->
               </div>
               <!-- end col -->
               <div class="col-md-6">
                  <div class="post-media wow fadeIn">
                     <img src="images/puntendoc/thumbnail.png" alt="" class="img-responsive">
                     <a href="https://www.youtube.com/watch?v=Q0Al4yJXWHs&t=1s&ab_channel=DzikraMuhamadshafi" data-rel="prettyPhoto[gal]" class="playbutton"><i class="flaticon-play-button"></i></a>
                  </div>
                  <!-- end media -->
               </div>
               <!-- end col -->
            </div>
            <!-- end row -->
            <hr class="hr1">
            <div class="row">
               <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="service-widget">
                     <div class="post-media wow fadeIn">
                        <a href="images/clinic_01.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                        <img src="images/clinic_01.jpg" alt="" class="img-responsive">
                     </div>
                     <h3>Fastest Respon Chat</h3>
                  </div>
                  <!-- end service -->
               </div>
               <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="service-widget">
                     <div class="post-media wow fadeIn">
                        <a href="images/clinic_02.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                        <img src="images/clinic_02.jpg" alt="" class="img-responsive">
                     </div>
                     <h3>Hygienic Operating Room</h3>
                  </div>
                  <!-- end service -->
               </div>
               <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="service-widget">
                     <div class="post-media wow fadeIn">
                        <a href="images/clinic_03.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                        <img src="images/clinic_03.jpg" alt="" class="img-responsive">
                     </div>
                     <h3>Specialist Physicians</h3>
                  </div>
                  <!-- end service -->
               </div>
               <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="service-widget">
                     <div class="post-media wow fadeIn">
                        <a href="images/clinic_01.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="flaticon-unlink"></i></a>
                        <img src="images/clinic_01.jpg" alt="" class="img-responsive">
                     </div>
                     <h3>Digital Control Center</h3>
                  </div>
                  <!-- end service -->
               </div>
            </div>
            <!-- end row -->
         </div>
         <!-- end container -->
      </div>
      <div id="service" class="services wow fadeIn">
         <!-- <div class="container"> -->
            <div class="row">
               <!-- <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12"> -->
                  <div class="inner-services">
                     <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="serv">
                           <span class="icon-service"><img src="images/puntendoc/fast-time.png" alt="#"></span>
                           <h4>FAST RESPON CHAT DOCTOR</h4>
                           <p>Get a quick response as your medical aid at PuntenDoc</p>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="serv">
                           <span class="icon-service"><img src="images/puntendoc/customer-service.png" alt="#" /></span>
                           <h4>QUALIFIED AND FRIENDLY DOCTOR</h4>
                           <p>Doctor who is friendly and ready to help</p>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="serv">
                           <span class="icon-service"><img src="images/puntendoc/hospital.png" alt="#" /></span>
                           <h4>HOSPITALS INTEGRITY</h4>
                           <p>Integrated throughout Indonesia</p>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="serv">
                           <span class="icon-service"><img src="images/puntendoc/quality-service.png" alt="#" /></span>
                           <h4>QUALITY SERVICE</h4>
                           <p>Quality service from PuntenDoc</p>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="serv">
                           <span class="icon-service"><img src="images/puntendoc/control-system.png" alt="#" /></span>
                           <h4>CONTROL SYSTEM</h4>
                           <p>PuntenDoc have a controlled system</p>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="serv">
                           <span class="icon-service"><img src="images/puntendoc/security.png" alt="#" /></span>
                           <h4>SECRITY</h4>
                           <p>Protected security</p>
                        </div>
                     </div>
                  </div>
            </div>
      </div>
      <div class="containercard">
         <div class="row team-items">
            <div class="col-md-2 single-item">
               <div class="cards-list">
                  <div class="card">
                     <div class="card_image"><a href="#"><img src="images/puntendoc/gambar2.jpg"/></a></div>
                     <div class="card_title title-white">
                        <p><strong>Chat Doctor</strong></p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-2 single-item">
               <div class="cards-list">
                  <div class="card">
                     <div class="card_image"><a href="#"><img src="images/puntendoc/gambar3.jpg"/></a></div>
                     <div class="card_title title-white">
                        <p><strong>BMI Calculator</strong></p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-2 single-item">
               <div class="cards-list">
                  <div class="card">
                     <div class="card_image"><a href="#"><img src="images/puntendoc/gambar4.jpg"/></a></div>
                     <div class="card_title title-white">
                        <p><strong>Animal Health</strong></p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-2 single-item">
               <div class="cards-list">
                  <div class="card">
                     <div class="card_image"><a href="#"><img src="images/puntendoc/gambar5.jpg"/></a></div>
                     <div class="card_title title-white">
                        <p><strong>Covid-19 Test</strong></p>
                     </div>
                  </div>
               </div>
            </div>
                  <div class="col-md-2 single-item">
               <div class="cards-list">
                  <div class="card">
                     <div class="card_image"><a href="#"><img src="images/puntendoc/gambar6.jpg"/></a></div>
                     <div class="card_title title-white">
                        <p><strong>Article</strong></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
	
	<!-- doctor -->
   <section>
         <section class="team-page-section" pt-5>
            <div class="container">
                  <!-- Sec Title -->
                  <div class="heading">
                     <span class="icon-logo"><img src="images/puntendoc/logopuntendoc.png" alt="#"></span>
                     <h2>Our Doctor</h2>
                  </div>

                  <div class="row clearfix">

                     <!-- Team Block -->
                     <?php $ambil = $koneksi->query("SELECT * FROM datadoctor WHERE id_doctor <= 3"); ?>
                     <?php while($perproduk = $ambil->fetch_assoc()){ ?>
                     <div class="team-block col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                              <ul class="social-icons">
                                 <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                 <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                 <li><a href="#"><i class="fab fa-skype"></i></a></li>

                                 <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                              </ul>
                              <div class="image">
                                 <a href="#"><img src="../imgdoc/<?php echo $perproduk['foto']; ?>" style="width: 300px; height: 400px;" /></a>
                              </div>
                              <div class="lower-content">
                                 <h3><a href="#"><?php echo $perproduk['fullname']; ?></a></h3>
                                 <div class="designation"><?php echo $perproduk['spcdokter']; ?></div>
                                 <div class="designation"><?php echo $perproduk['email']; ?></div>
                              </div>
                        </div>

                     </div>
                     <!-- Team Block -->
                      <?php } ?>
                  </div>
            </div>
            <div class="row text-center">
               <div class="pricing-table-sign-up">
                  <a href="viewmoredoctor.php" data-scroll="" class="btn btn-light btn-radius btn-brd grd1 effect-1">View More</a>
               </div>
            </div>
         </section>
   </section>

   <section id="team" class="team-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="site-heading text-center">
                        <h2>Our <span>Hospitals Collaboration</span></h2>
                        <h4>integrated throughout Indonesia</h4>
                    </div>
                </div>
            </div>
                <div class="row team-items">
                  <?php $ambil = $koneksi->query("SELECT * FROM datarumahsakit WHERE id_rumahsakit <= 6"); ?>
                  <?php while($perproduk = $ambil->fetch_assoc()){ ?>
                    <div class="col-md-4 single-item">
                        <div class="item">
                           
                            <div class="thumb">
                                <img class="img-fluid" src="../imgrs/<?php echo $perproduk['foto']; ?>" alt="Thumb">
                                <div class="overlay">
                                    <h4><?php echo $perproduk['notelprs']; ?></h4>
                                    <p>
                                       <?php echo $perproduk['email']; ?>
                                    </p>
                                    <div class="social">
                                        <ul>
                                            <li class="twitter">
                                             
                                                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                                            </li>
                                            <li class="pinterest">
                                                <a href="#"><i class="fab fa-pinterest"></i></a>
                                            </li>
                                            <li class="instagram">
                                                <a href="#"><i class="fab fa-instagram"></i></a>
                                            </li>
                                            <!-- <li class="vimeo">
                                                <a href="#"><i class="fab fa-vimeo-v"></i></a>
                                            </li> -->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="info">
                                <span class="message">
                                    <a href="#"><i class="fa-regular fa-message"></i></a>
                                </span>
                                <h4><?php echo $perproduk['nama']; ?></h4>
                                <span><?php echo $perproduk['alamat']; ?></span>
                            </div>
                        
                        </div>
                  </div>
                  <?php } ?>
               </div>
         </div>
         <div class="row text-center">
            <div class="pricing-table-sign-up">
               <a href="viewmorehospitals.php" data-scroll="" class="btn btn-light btn-radius btn-brd grd1 effect-1">View More</a>
            </div>
         </div>
    </section>

   
	  
	  <div id="price" class="section pr wow fadeIn" style="background-image:url('images/price-bg.png');">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="tab-content">
                     <div class="tab-pane active fade in" id="tab1">
                        <div class="row text-center">
                           <?php $ambil = $koneksi->query("SELECT * FROM produk"); ?>
                           <?php while($perproduk = $ambil->fetch_assoc()){ ?>
                           <div class="col-md-4">
                              <div class="pricing-table pricing-table-highlighted">
                                 <div class="pricing-table-header grd1">
                                    <h2><?php echo $perproduk['nama']; ?></h2>
                                    <h3>Rp. <?php echo number_format($perproduk['price']); ?></h3>
                                 </div>
                                 <div class="pricing-table-space"></div>
                                 <div class="pricing-table-text">
                                    <p>This is a perfect choice for you!</p>
                                 </div>
                                 <div class="pricing-table-features">
                                    <p><i class="fa-brands fa-rocketchat"></i> <strong>One</strong> Chat Doctor</p>
                                    <p><i class="fa fa-rocket"></i> <strong>Fast</strong> Response Chat</p>
                                    <p><i class="fa-regular fa-bookmark"></i> <strong>Saved</strong> Diagnostic Result</p>
                                    <p><i class="fa fa-clock-o"></i> <strong>45</strong> Minutes</p>
                                    <p><i class="fa-solid fa-medal"></i> <strong>Our</strong> Best Doctor</p>
                                    <p><i class="fa-regular fa-address-card"></i> <strong>Free</strong> Registration Hospital</p>
                                 </div>
                                 <div class="pricing-table-sign-up">
                                    <a href="beli.php?id=<?php echo $perproduk['id_produk']; ?>" data-scroll="" class="btn btn-light btn-radius btn-brd grd1 effect-1">Order Now</a>
                                 </div>
                              </div>
                           </div>
                           <?php } ?>
                        </div>
                        <!-- end row -->
                     </div>
                     <!-- end pane -->
                     
                        <!-- end row -->
                     
                     <!-- end pane -->
                  </div>
                  <!-- end content -->
               </div>
               <!-- end col -->
            </div>
         </div>
      </div>
	  
	  <!-- end doctor section -->
	  
      <div id="testimonials" class="section wb wow fadeIn">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/puntendoc/logopuntendoc.png" alt="#"></span>
               <h2>Testimonials</h2>
            </div>
            <!-- end title -->
            <div class="row">
               <?php $ambil = $koneksi->query("SELECT * FROM dataclient WHERE id_client = 1"); ?>
               <?php while($perproduk = $ambil->fetch_assoc()){ ?>
               <div class="col-md-6 col-sm-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.2s">
                  <div class="testimonial clearfix">
                     <div class="desc">
                        <h3><i class="fa fa-quote-left"></i><?php echo $perproduk['judulfb']; ?></h3>
                        <p class="lead"><?php echo $perproduk['isifb']; ?></p>
                     </div>
                     <div class="testi-meta">
                        <img src="images/testi_01.png" alt="" class="img-responsive alignleft">
                        <h4><?php echo $perproduk['namalengkap']; ?> <small>- <?php echo $perproduk['email']; ?></small></h4>
                     </div>
                     <!-- end testi-meta -->
                  </div>
                  <!-- end testimonial -->
               </div>
               <?php } ?>
               <!-- end col -->
               <?php $ambil = $koneksi->query("SELECT * FROM dataclient WHERE id_client = 2"); ?>
               <?php while($perproduk = $ambil->fetch_assoc()){ ?>
               <div class="col-md-6 col-sm-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.4s">
                  <div class="testimonial clearfix">
                     <div class="desc">
                        <h3><i class="fa fa-quote-left"></i> <?php echo $perproduk['judulfb']; ?></h3>
                        <p class="lead"><?php echo $perproduk['isifb']; ?></p>
                     </div>
                     <div class="testi-meta">
                        <img src="images/testi_02.png" alt="" class="img-responsive alignleft">
                        <h4><?php echo $perproduk['namalengkap']; ?> <small>- <?php echo $perproduk['email']; ?></small></h4>
                     </div>
                     <!-- end testi-meta -->
                  </div>
                  <!-- end testimonial -->
               </div>
               <?php } ?>
               <!-- end col -->
            </div>
            <!-- end row -->
            <hr class="invis">
            <div class="row">
               <?php $ambil = $koneksi->query("SELECT * FROM dataclient WHERE id_client = 3"); ?>
               <?php while($perproduk = $ambil->fetch_assoc()){ ?>
               <div class="col-md-6 col-sm-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.6s">
                  <div class="testimonial clearfix">
                     <div class="desc">
                        <h3><i class="fa fa-quote-left"></i><?php echo $perproduk['judulfb']; ?></h3>
                        <p class="lead"><?php echo $perproduk['isifb']; ?></p>
                     </div>
                     <div class="testi-meta">
                        <img src="images/testi_03.png" alt="" class="img-responsive alignleft">
                        <h4><?php echo $perproduk['namalengkap']; ?> <small>- <?php echo $perproduk['email']; ?></small></h4>
                     </div>
                     <!-- end testi-meta -->
                  </div>
                  <!-- end testimonial -->
               </div>
               <?php } ?>
               <!-- end col -->
               <?php $ambil = $koneksi->query("SELECT * FROM dataclient WHERE id_client = 4"); ?>
               <?php while($perproduk = $ambil->fetch_assoc()){ ?>
               <div class="col-md-6 col-sm-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.8s">
                  <div class="testimonial clearfix">
                     <div class="desc">
                        <h3><i class="fa fa-quote-left"></i> <?php echo $perproduk['judulfb']; ?></h3>
                        <p class="lead"> <?php echo $perproduk['isifb']; ?></p>
                     </div>
                     <div class="testi-meta">
                        <img src="images/testi_01.png" alt="" class="img-responsive alignleft">
                        <h4><?php echo $perproduk['namalengkap']; ?> <small>- <?php echo $perproduk['email']; ?></small></h4>
                     </div>
                     <!-- end testi-meta -->
                  </div>
                  <!-- end testimonial -->
               </div>
               <?php } ?>
               <?php $ambil = $koneksi->query("SELECT * FROM dataclient WHERE id_client = 4"); ?>
               <?php while($perproduk = $ambil->fetch_assoc()){ ?>
               <div class="col-md-6 col-sm-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.8s">
                  <div class="testimonial clearfix">
                     <div class="desc">
                        <h3><i class="fa fa-quote-left"></i> <?php echo $perproduk['judulfb']; ?></h3>
                        <p class="lead"> <?php echo $perproduk['isifb']; ?></p>
                     </div>
                     <div class="testi-meta">
                        <img src="images/testi_01.png" alt="" class="img-responsive alignleft">
                        <h4><?php echo $perproduk['namalengkap']; ?> <small>- <?php echo $perproduk['email']; ?></small></h4>
                     </div>
                     <!-- end testi-meta -->
                  </div>
                  <!-- end testimonial -->
               </div>
               <?php } ?>
               <!-- end col -->
            </div>
            <!-- end row -->
         </div>
         <!-- end container -->
      </div>
      <!-- end section -->
      <div id="getintouch" class="section wb wow fadeIn" style="padding-bottom:0;">
         <div class="container">
            <div class="heading">
               <span class="icon-logo"><img src="images/puntendoc/logopuntendoc.png" alt="#"></span>
               <h2>Integrated Hospitals</h2>
            </div>
         </div>
         <div class="contact-section">
            <div class="form-contant">
               <form id="ajax-contact" action="assets/mailer.php" method="post">
                  <div class="row">
                     <div class="col-md-6">
                        <div class="form-group in_name">
                           <input type="text" class="form-control" placeholder="Name" required="required">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group in_email">
                           <input type="email" class="form-control" placeholder="E-mail" required="required">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group in_email">
                           <input type="tel" class="form-control" id="phone" placeholder="Phone" required="required">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group in_email">
                           <input type="text" class="form-control" id="subject" placeholder="Subject" required="required">
                        </div>
                     </div>
                     <div class="col-md-12">
                        <div class="form-group in_message"> 
                           <textarea class="form-control" id="message" rows="5" placeholder="Message" required="required"></textarea>
                        </div>
                        <div class="actions">
                           <input type="submit" value="Send Message" name="submit" id="submitButton" class="btn small" title="Submit Your Message!">
                        </div>
                     </div>
                  </div>
               </form>
            </div>
            <div id="googleMap" style="width:100%;height:450px;"></div>
         </div>
      </div>
      <footer id="footer" class="footer-area wow fadeIn">
         <div class="container">
            <div class="row">
               <div class="col-md-4">
                  <div class="logo padding">
                     <a href=""><img src="images/puntendoc/PuntenDocwteks1.png" alt=""></a>
                     <p>Health is our priority</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="footer-info padding">
                     <h3>CONTACT US</h3>
                     <p><i class="fa fa-map-marker" aria-hidden="true"></i> Richmond Bekasi Utara Jawa Barat Indonesia</p>
                     <p><i class="fa fa-paper-plane" aria-hidden="true"></i> dzikramuhamadshafi11@gmail.com</p>
                     <p><i class="fa fa-phone" aria-hidden="true"></i> (+62) 817 7541 8179</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="subcriber-info">
                     <h3>SUBSCRIBE</h3>
                     <p>Get healthy news, tip and solutions to your problems from our experts.</p>
                     <div class="subcriber-box">
                        <form id="mc-form" class="mc-form">
                           <div class="newsletter-form">
                              <input type="email" autocomplete="off" id="mc-email" placeholder="Email address" class="form-control" name="EMAIL">
                              <button class="mc-submit" type="submit"><i class="fa fa-paper-plane"></i></button> 
                              <div class="clearfix"></div>
                              <!-- mailchimp-alerts Start -->
                              <div class="mailchimp-alerts">
                                 <div class="mailchimp-submitting"></div>
                                 <!-- mailchimp-submitting end -->
                                 <div class="mailchimp-success"></div>
                                 <!-- mailchimp-success end -->
                                 <div class="mailchimp-error"></div>
                                 <!-- mailchimp-error end -->
                              </div>
                              <!-- mailchimp-alerts end -->
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <div class="copyright-area wow fadeIn">
         <div class="container">
            <div class="row">
               <div class="col-md-8">
                  <div class="footer-text">
                     <p>© 2022 PuntenDoc. Health Is Our Priority.</p>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="social">
                     <ul class="social-links">
                        <li><a href=""><i class="fa fa-rss"></i></a></li>
                        <li><a href=""><i class="fa fa-facebook"></i></a></li>
                        <li><a href=""><i class="fa fa-twitter"></i></a></li>
                        <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                        <li><a href=""><i class="fa fa-youtube"></i></a></li>
                        <li><a href=""><i class="fa fa-pinterest"></i></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end copyrights -->
      <a href="#home" data-scroll class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>
      <!-- all js files -->
      <script src="js/all.js"></script>
      <!-- all plugins -->
      <script src="js/custom.js"></script>
      <!-- map -->
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCNUPWkb4Cjd7Wxo-T4uoUldFjoiUA1fJc&callback=myMap"></script>
   </body>
</html>
