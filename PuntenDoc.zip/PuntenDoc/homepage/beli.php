<?php
session_start();

$id_produk = $_GET['id'];


$_SESSION['keranjang'][$id_produk] = 1;


echo "<script>alert('Paket ditambhkan');</script>";
echo "<script>location='checkout.php';</script>";

// echo "<pre>";
// print_r($_SESSION);
// echo "</pre>";
?>
<!-- <html>
    <a href="batal.php">batal</a>
</html> -->