<?php
session_start();
  // skrip koneksi
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
    <title>Result Diagnosis Patient</title>
</head>
<body>
    <header>
        <div class="text-box">
            <h1 id="title">Result Diagnosis Patient</h1><hr>
            <p id="description">Draw conclusions about what the patient is experiencing</p>
        </div>
        </header>
            <div class="container">
                <a href="../doctorpage.php"><i class="fa-solid fa-house-user"></i></a>
            <form id="survey-form" method="post">

                <div class="labels">
                <label id="name-label">* Date</label></div>
                <div class="input-tab">
                <input class="input-field" type="date" id="name" name="tanggal" placeholder="Enter date" required autofocus></div>

                <div class="labels">
                <label id="email-label" for="email">* Fullname</label></div>
                <div class="input-tab">
                <input class="input-field" type="text" id="email" name="namapasien" placeholder="Enter pateint name" required></div>

                <div class="labels">
                <label id="number-label" for="number">* Age</label></div>
                <div class="input-tab">
                <input class="input-field" type="number" id="number" name="umur" min="1" max="120" placeholder="15" required></div>

                <div class="labels">
                <label id="number-label" for="number">Patient's diagnostic name</label></div>
                <div class="input-tab">
                <input class="input-field" type="text" id="number" name="namadianogsa" min="1" max="120" placeholder="Patient Diagnostic Name" required></div>

                <div class="labels">
                <label id="number-label" for="number">Medicine</label></div>
                <div class="input-tab">
                <input class="input-field" type="text" id="number" name="namaobat" min="1" max="120" placeholder="Medicine Name" required></div>

                <div class="labels">
                <label for="comments">Suggestion</label></div>
                <div class="input-tab">
                <textarea class="input-field" id="comments" name="saran" rows="10" cols="40" placeholder="Your uggestion"></textarea></div>

                <div class="labels">
                <label for="comments">Medical Prescription</label></div>
                <div class="input-tab">
                <textarea class="input-field" id="comments" name="resepobat" rows="10" cols="40" placeholder="This content is for prescription medicine"></textarea></div>

                <div class="btn">
                <button id="submit" name="submit" type="submit">Submit</button>
                </div>
            </form>
            </div>
            <?php 
    if (isset($_POST["submit"])) {
        $tanggal = $_POST['tanggal'];
        $namapasien = $_POST['namapasien'];
        $umur = $_POST['umur'];
        $namadianogsa = $_POST['namadianogsa'];
        $namaobat = $_POST['namaobat'];
        $saran = $_POST['saran'];
        $resepobat = $_POST['resepobat'];

        $koneksi->query("INSERT INTO datadianogsapasien (tanggal, namapasien, umur, namadianogsa, namaobat, saran, resepobat) VALUES ('$tanggal', '$namapasien', '$umur', '$namadianogsa', '$namaobat', '$saran', '$resepobat')");
        
        echo "<script>alert('Data berhasil di simpan');</script>";
        echo "<script>location='../doctorpage.php';</script>";
    }
    ?>
        <footer>
        </footer>

</body>
</html>


