<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Notification</title>
        <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="style1.css">
</head>
<body>
        <div class="navbar">
        <li class="list-item"><a href="../doctorpage.php"><i class="fa-solid fa-house"></i></a>
            <span class="list-item-name">Home</span>
        </li>
        <li class="list-item"><a href="../myprofile.php"><i class="fa-solid fa-user"></i></a>
            <span class="list-item-name">Profile</span>
        </li>
        <li class="list-item"><a href=""><i class="fa-solid fa-gear"></i></a>
            <span class="list-item-name">Settings</span>
        </li>
        <li class="list-item"><a href=""><i class="fa-solid fa-bag-shopping"></i></a>
            <span class="list-item-name">Bag</span>
        </li>
    </div>
    <div class="container">
        <div class="konten">
            <h1>New Notification</h1>
            <button type="button" class="btn btn-primary" data-toggle="dropdown"><i class="fa-regular fa-bell fa-2x" id="notif"></i>
            </button>
            <div id="pesan" class="dropdown-menu" aria-labelledby="dropdownMenuButton"></div>
        </div>
        <div class="isi">
            <a href="../../ChatApp/login.php" target="_blank"><i class="fa-regular fa-comments fa-2x" id="notif"></i></a>
            <div id="pesan" class="dropdown-menu" aria-labelledby="dropdownMenuButton"></div>
        </div>
    </div>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
        </script>
    
        <script src="https://code.jquery.com/jquery-3.5.1.js"
            integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
        <script type="text/javascript" src="tampil.js"></script>
    </body>
    
    </html>