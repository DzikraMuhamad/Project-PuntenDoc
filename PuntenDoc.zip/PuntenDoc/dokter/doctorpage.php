<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");

if (!isset($_SESSION['doctor'])) {
    echo "<script>alert('Silahkan Login');</script>";
    echo "<script>location='login/login.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/logopuntendoc.png" type="image/x-icon" />
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
    <title>Doctor Homepage</title>
</head>
<body>
    <header> 
    <nav class="navigation">
        <div class="logotype">PuntenDoc</div>
        <ul class="categories">
        <li class="category-item link-1"><a href="myprofile.php">My Profile</a></li>
        <li class="category-item link-1"><a href="#">My Client</a></li>
        <li class="category-item link-1"><a href="#">Experience</a></li>
        <li class="category-item link-1"><a href="#">History</a></li>
        </ul>
    </nav>
    <div class="search">
        <input type="search" placeholder="Type to search..."/>
    </div>
    </header>
    <div class="wrapper">
    <aside class="sidebar">
        <ul class="sidebar-list">
        <a href="form/form.php"><li class="sidebar-item"><i class="fa-solid fa-square-poll-vertical"></i></li></a>
        <a href=""><li class="sidebar-item sb-active"><i class="fa fa-th"></i></li></a>
        <a href=""><li class="sidebar-item"><i class="fa-solid fa-sack-dollar"></i></li></a>
        <a href="realtimenotif/index.php"><li class="sidebar-item"><i class="fa fa-bell-o"></i></li></a>
        <a href=""><li class="sidebar-item"><i class="fa fa-bolt"></i></li></a>
        <a href="login/logout.php"><li class="sidebar-item"><i class="fa-solid fa-arrow-right-from-bracket"></i></li></a>
        </ul>
    </aside>
    <main class="content">
        <div class="feed-grid">
        <div class="card-half wide">
            <div class="card-img"><span class="label"> <i class="fa fa-star"></i></span><img src="img/download.jpg" alt="img"/></div>
            <div class="card-text">
            <h4>The Covid-19 pandemic has opened many eyes that the profession of doctors and health workers are heroes.</h4>
            <p>Doctor is a noble profession, accompany the glory of your profession with a sincere heart.</p>
            </div>
            <ul class="card-tools">
            <li class="tools-item"><i class="fa fa-heart like"></i><span class="tools-count">543</span></li>
            <li class="tools-item"><i class="fa fa-share share"></i></li>
            </ul>
        </div>
        <div class="card"><img src="img/1.jpg" alt="img"/>
            <a href="https://www.genmuda.com/10-skill-wajib-kalo-kamu-mau-jadi-dokter-yang-baik/" target="_blank"><div class="info-center">How to be a good doctor</div></a>
        </div>
        <div class="card"><img src="https://36.media.tumblr.com/1a6bf1c955f5278517f71d50b60ac89d/tumblr_nw46p7NOHH1qkegsbo2_540.jpg" alt="img"/>
            <a href="https://www.higienis.com/blog/hygiene-theater-perlukah-disinfeksi-ruangan/" target="_blank"><div class="info-center">Beautiful and hygienic room</div></a>
        </div>
        <div class="card"><img src="img/3.jpg" alt="img"/>
            <a href="https://www.cnnindonesia.com/internasional/20220706124435-106-817955/asosiasi-dokter-medis-dunia-tegaskan-idi-satu-satunya-wakil-ri" target="_blank"><div class="info-center">World association of medical doctors</div></a>
        </div>
        <div class="card-half wide">
            <div class="card-img"><a href="https://en.wikipedia.org/wiki/History_of_medicine"><img src="img/4.jpg" alt="img"/></a></div>
            <div class="card-text">
            <h4>History of medicine</h4>
            <p>Imhotep, the remarkable African physician whose skills were unrivaled in his time, eventually became known as the Egyptian god of medicine.</p>
            </div>
            <ul class="card-tools">
            <li class="tools-item"><i class="fa fa-heart like"></i><span class="tools-count">133</span></li>
            <li class="tools-item"><i class="fa fa-share share"></i></li>
            </ul>
        </div>
        <div class="card-half">
            <div class="card-img"><img src="https://www.chelseafc.com/content/cfc/en/homepage/news/boilerplate-config/latest-news/2015/11/pre-match-briefing--stoke-city-v-chelsea--part-two/_jcr_content.autoteaser.jpeg" alt="img"/></div>
            <div class="card-text">
            <h4>Pre-Match Briefing: Stoke City v Chelsea</h4>
            <p>We have a tea-time appointment in the Potteries later today.</p>
            </div>
            <ul class="card-tools">
            <li class="tools-item"><i class="fa fa-heart like"></i><span class="tools-count">4533</span></li>
            <li class="tools-item"><i class="fa fa-share share"></i></li>
            </ul>
        </div>
        <div class="card"> <img src="https://41.media.tumblr.com/7be0a9c6035a5eaaafaddab95a3d77ae/tumblr_mmp17zInpt1qhfgjbo1_540.jpg" alt="img"/>
            <div class="info-center">Best 100 memorable sports photos</div>
        </div>
        <div class="card"><img src="https://cdn-images-1.medium.com/max/600/1*wFiuAFruqIUTNU99xpb_zw.gif" alt="img"/>
            <div class="info-center">Long shadow is dead. Welcome Diffuse shadows.</div>
        </div>
        <div class="card"> <img src="https://40.media.tumblr.com/027d3fdde45d8cb950a74dd070cf8e90/tumblr_nxfo8rG3o81qzleu4_og_540.jpg" alt="img"/>
            <div class="info-center">12 Photos Of A Gorgeously Designed NYC Home</div>
        </div>
        <div class="card"><img src="https://40.media.tumblr.com/214255d33d16e6075d674c9cd84d9a6c/tumblr_no7630It9v1qd6rjmo1_540.jpg" alt="img"/>
            <div class="info-center">Christina Schneiderlin: Interview with the artist</div>
        </div>
        <div class="card-half">
            <div class="card-img"><span class="label"> <i class="fa fa-star"></i></span><img src="https://40.media.tumblr.com/682b6eb0bcafb090c26cda164a235f3b/tumblr_n04czvggDF1sv6eyto1_500.jpg" alt="img"/></div>
            <div class="card-text">
            <h4>You just should run</h4>
            <p>Learn how to run can improve your health.</p>
            </div>
            <ul class="card-tools">
            <li class="tools-item"><i class="fa fa-heart like"></i><span class="tools-count">8543</span></li>
            <li class="tools-item"><i class="fa fa-share share"></i></li>
            </ul>
        </div>
        </div>
    </main>
    </div>
    
</body>
</html>