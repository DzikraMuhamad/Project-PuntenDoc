<?php
if (!isset($_SESSION)) {
    session_start();
}

$conn = mysqli_connect("localhost", "root", "", "puntendoc");

function registrasi($data)
{
    global $conn;
    $username = strtolower(stripslashes($data['username']));
    $password = mysqli_real_escape_string($conn, $data['password']);
    $password2 = mysqli_real_escape_string($conn, $data['password2']);
    $result = mysqli_query($conn, "SELECT Username FROM user WHERE Username = '$username'");
    if (mysqli_fetch_assoc($result)){
        $_SESSION['ready'] = true;  
        // echo "<script>
        //     alert('Username sudah terdaftar');
        //     </script>";
        // return false;
        return;
    }
    if ($password != $password2){
        $_SESSION['wrong'] = true;
        // echo "<script>
        //     alert('Password tidak sesuai, Mohon cek kembali dengan benar');
        //     </script>";
        // return false;
        return;
    }
    $password = password_hash($password, PASSWORD_DEFAULT);
    mysqli_query($conn, "INSERT INTO user VALUE ('', '$username', '$password')");

    return mysqli_affected_rows($conn);

}

function login($data)
{
    // memanggil global variable $conn
    global $conn;

    $email = $_POST['email'];
    $password = $_POST['password'];
    //cek username
    $result = mysqli_query($conn,"SELECT * FROM datadoctor WHERE email = '$email'");
    if (mysqli_num_rows($result) === 1){
        //cek password
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])){
            // kalo login berhasil
            $_SESSION['login'] = true;
            $_SESSION['id'] = $row['id_doctor'];
            $_SESSION['sukses'] = true;
            return;
        }else{
            echo "<script>
            alert('Password salah');
            </script>";
        }
    }else{
        echo "<script>
        alert('Usermame salah');
        </script>";
    }
}

function update($data, $data_id) {
    global $conn;

    $data_nama = htmlspecialchars($data['data_nama']);
    $data_email = htmlspecialchars($data['data_email']);
    $data_bio = htmlspecialchars($data['data_bio']);


    mysqli_query($conn, "UPDATE mahasiswa SET data_nama='$data_nama', data_email='$data_email', data_bio='$data_bio' WHERE id='$data_id'");
    return mysqli_affected_rows($conn);
}
?>