<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");

?>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styleprofile.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
	<title>Document</title>
</head>
<body>
	<div class="container mt-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-7">
            <div class="card p-3 py-4">
                <div class="text-center">
                    <img src="../admin/img/<?php echo $SESSION['doctor']['foto']; ?>" width="100" class="rounded-circle">
                </div>
                
                <div class="text-center mt-3">
                    <span class="bg-secondary p-1 px-4 rounded text-white"><?php echo $_SESSION['doctor']['spcdokter']?></span>
                    <h5 class="mt-2 mb-0"><?php echo $_SESSION['doctor']['fullname']?></h5>
                    <span><?php echo $_SESSION['doctor']['email']?></span>
                    
                    <div class="px-4 mt-1">
                        <p class="fonts"><?php echo $_SESSION['doctor']['notelp']?>. <?php echo $_SESSION['doctor']['nik']?>. <?php echo $_SESSION['doctor']['password']?></p>
                    </div>
                    
                     <ul class="social-list">
                        <li><i class="fa fa-facebook"></i></li>
                        <li><i class="fa fa-dribbble"></i></li>
                        <li><i class="fa fa-instagram"></i></li>
                        <li><i class="fa fa-linkedin"></i></li>
                        <li><i class="fa fa-google"></i></li>
                    </ul>
                    
                    <div class="buttons">
                        <a href="doctorpage.php"><i class="fa-solid fa-arrow-left-long"></i></a>
                        <a href="editprofile.php"><i class="fa-solid fa-paintbrush"></i></a>
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>
    
</div>
</body>
</html>