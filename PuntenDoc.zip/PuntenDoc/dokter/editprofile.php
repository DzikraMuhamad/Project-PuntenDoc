<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    <title>Document</title>
</head>
<body>
    <div class="container rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-md-3 border-right">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"><span class="font-weight-bold"><?php echo $_SESSION['doctor']['fullname']?></span><span class="text-black-50"><?php echo $_SESSION['doctor']['email']?></span><span> </span></div>
            </div>
            <div class="col-md-5 border-right">
                <div class="p-3 py-5">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="text-right">Profile Settings</h4>
                    </div>
                    <pre>
                    <?php print_r($_SESSION["doctor"]); ?>
                    </pre>
                    <form method="post">
                        <div class="row mt-2">
                            <div class="col-md-12"><label class="labels">Full Name</label><input type="text" class="form-control" placeholder="fullname" name="firstname" value="<?php echo $_SESSION['doctor']['fullname']?>"></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12"><label class="labels">NIK</label><input type="number" class="form-control" placeholder="enter nik" name="nikdoctor" value="<?php echo $_SESSION['doctor']['nik']?>"></div>
                            <div class="col-md-12"><label class="labels">Email</label><input type="text" class="form-control" placeholder="enter email" name="emaildoctor" value="<?php echo $_SESSION['doctor']['email']?>"></div>
                            <div class="col-md-12"><label class="labels">Password</label><input type="text" class="form-control" placeholder="enter password" name="password" value="<?php echo $_SESSION['doctor']['password']?>"></div>
                            <div class="col-md-12"><label class="labels">Doctor Specialist</label><input type="text" class="form-control" placeholder="enter specialist doctor" name="spclstdoctor" value="<?php echo $_SESSION['doctor']['spcdokter']?>"></div>
                            <div class="col-md-12"><label class="labels">Phone Number</label><input type="number" class="form-control" placeholder="enter phone number" name="phonenumber" value="<?php echo $_SESSION['doctor']['notelp']?>"></div>
                            <div class="col-md-12"><label class="labels">Address</label><input type="text" class="form-control" placeholder="enter address" name="addressdoctor" value="<?php echo $_SESSION['doctor']['alamat']?>"></div>
                            <div class="col-md-12"><label class="labels">Gender</label><input type="text" class="form-control" placeholder="enter gender" name="genderdoctor" value="<?php echo $_SESSION['doctor']['jkelamin']?>"></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6"><label class="labels">Change Photo</label><input type="file" class="form-control" name="foto"></div>
                        </div>
                        <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="button" name="change">Save Profile</button></div>
                    </form>
                </div>
            </div>
            <?php 
                    if (isset($_POST['change'])) {
                        $namafoto = $_FILES['foto']['name'];
                        $lokasifoto = $_FILES['foto']['tmp_name'];
                        $id_doctor = $_SESSION['doctor']['id_doctor'];
                        // jika foto di rubah
                        if (!empty($lokasifoto)) {
                            move_uploaded_file($lokasifoto, "../admin/img/$namafoto");
                            $koneksi->query("UPDATE datadoctor SET nik='$_POST[nikdoctor]', fullname='$_POST[firstname]',
                            spcdokter='$_POST[spclstdoctor]', email='$_POST[emaildoctor]',
                            alamat='$_POST[addressdoctor]', jkelamin='$_POST[genderdoctor]', notelp='$_POST[phonenumber]', 
                            foto='$namafoto' WHERE id_doctor='$id_doctor'");
                        } else {
                            $koneksi->query("UPDATE datadoctor SET nik='$_POST[nikdoctor]', fullname='$_POST[firstname]',
                            spcdokter='$_POST[spclstdoctor]', email='$_POST[emaildoctor]',
                            alamat='$_POST[addressdoctor]', jkelamin='$_POST[genderdoctor]', notelp='$_POST[phonenumber]' 
                            WHERE id_doctor='$id_doctor'");
                        }
                        echo "<script>alert('Data telah diubah');</script>";
                        echo "<script>location='myprofile.php';</script>";
                    }
                    ?>
        </div>
    </div>
</body>
</html>