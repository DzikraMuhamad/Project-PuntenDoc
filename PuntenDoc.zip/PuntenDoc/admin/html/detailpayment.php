<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Payment</title>
</head>
<body>
    <section class="detailpembayaran">
        <div class="col-lg-11 mb-4 order-0" style="margin: auto;">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Detail Payment Data</h5>
                            <?php
                            $ambil = $koneksi->query("SELECT * FROM dataclient JOIN datapembayaran ON dataclient.id_client = datapembayaran.id_pelanggan WHERE id_client = '$_GET[id]'");
                            $detail = $ambil->fetch_assoc();
                            ?>
                            <pre><?php print_r($detail); ?></pre>
                            <strong><?php echo $detail['namalengkap']; ?></strong> <br>
                            <p>
                                <?php echo $detail['notelp']; ?> <br>
                                <?php echo $detail['email']; ?>
                            </p>
                            <p>
                                Date : <?php echo $detail['tanggal_pembelian']; ?> <br>
                                Price : <?php echo $detail['total_pembelian']; ?>
                            </p>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Doctor ID</th>
                                        <th>Date</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor = 1; ?>
                                    <?php $ambil=$koneksi->query("SELECT * FROM dataclient JOIN orderan ON dataclient.id_client = orderan.id_orderan WHERE dataclient.id_client='$_GET[id]'"); ?>
                                    <?php while($pecah=$ambil->fetch_assoc()){ ?>
                                    <tr>
                                        <td><?php echo $pecah['id_orderan']; ?></td>
                                        <td><?php echo $pecah['id_doctor']; ?></td>
                                        <td><?php echo $pecah['tanggal']; ?></td>
                                        <td><?php echo $pecah['namapaket']; ?></td>
                                    </tr>
                                    <?php $nomor++; ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>