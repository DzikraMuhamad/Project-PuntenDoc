<div class="col-lg-11 mb-4 order-0" style="margin: auto;">
    <div class="card">
        <div class="d-flex align-items-end row">
            <div class="">
                <div class="card-body">
                    <h5 class="card-title text-primary">Modify Hospital</h5>
                    <?php 
                    $ambil = $koneksi->query("SELECT * FROM datarumahsakit WHERE id_rumahsakit='$_GET[id]'");
                    $pecah = $ambil->fetch_assoc();

                    echo "<pre>";
                    print_r($pecah);
                    echo "</pre>";
                    ?>
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">ID Hospital</label>
                            <input type="number" class="form-control" name="idrumahsakit" value="<?php echo $pecah['id_rumahsakit']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Hospital</label>
                            <input type="text" class="form-control" name="namarumahsakit" value="<?php echo $pecah['nama']; ?>">
                        <div class="form-group">
                            <label for="">Grade</label>
                            <input type="text" class="form-control" name="graderumahsakit" value="<?php echo $pecah['grade']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" class="form-control" name="emailrumahsakit" value="<?php echo $pecah['email']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Phone Number</label>
                            <input type="number" class="form-control" name="telprumahsakit" value="<?php echo $pecah['notelprs']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Address</label>
                            <input type="text" class="form-control" name="addressrumahsakit" value="<?php echo $pecah['alamat']; ?>">
                        </div>
                        <div class="form_group">
                            <img src="../../imgrs/<?php echo $pecah['foto'] ?>" width="200">
                        </div>
                        <div class="form-group">
                            <label>Change Photo</label>
                            <input type="file" name="foto" class="form-control">
                        </div>
                        <button class="btn btn-primary" name="change">Change</button>
                    </form>
                    <?php 
                    if (isset($_POST['change'])) {
                        $namafoto = $_FILES['foto']['name'];
                        $lokasifoto = $_FILES['foto']['tmp_name'];
                        // jika foto di rubah
                        if (!empty($lokasifoto)) {
                            move_uploaded_file($lokasifoto, "../../imgrs/$namafoto");
                            $koneksi->query("UPDATE datarumahsakit SET id_rumahsakit='$_POST[idrumahsakit]', nama='$_POST[namarumahsakit]',
                            grade='$_POST[graderumahsakit]', email='$_POST[emailrumahsakit]', 
                            notelprs='$_POST[telprumahsakit]', alamat='$_POST[addressrumahsakit]', foto='$namafoto' WHERE id_rumahsakit='$_GET[id]'");
                        } else {
                            $koneksi->query("UPDATE datarumahsakit SET id_rumahsakit='$_POST[idrumahsakit]', nama='$_POST[namarumahsakit]',
                            grade='$_POST[graderumahsakit]', email='$_POST[emailrumahsakit]', 
                            notelprs='$_POST[telprumahsakit]', alamat='$_POST[addressrumahsakit]' WHERE id_rumahsakit='$_GET[id]'");
                        }
                        echo "<script>alert('Data Rumah Sakit Telah Diubah');</script>";
                        echo "<script>location='index.php?halaman=hospitals';</script>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>