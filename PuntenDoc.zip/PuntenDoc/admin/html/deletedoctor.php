<?php
$ambil = $koneksi->query("SELECT * FROM datadoctor WHERE id_doctor='$_GET[id]'");
$pecah = $ambil->fetch_assoc();
$fotodoctor = $pecah['photo'];
if (file_exists("../img/$fotodoctor")) {
    unlink("../img/$fotodoctor");
}
$koneksi->query("DELETE FROM datadoctor WHERE id_doctor='$_GET[id]'");
echo "<script>alert('Doctor Terhapus');</script>";
echo "<script>location='index.php?halaman=doctor';</script>";
?>
