<div class="col-lg-11 mb-4 order-0" style="margin: auto;">
    <div class="card">
        <div class="d-flex align-items-end row">
            <div class="">
                <div class="card-body">
                    <h5 class="card-title text-primary">Add Hospital</h5>
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">ID Hospital</label>
                            <input type="number" class="form-control" name="idrumahsakit">
                        </div>
                        <div class="form-group">
                            <label for="">Hospital</label>
                            <input type="text" class="form-control" name="namarumahsakit">
                        <div class="form-group">
                            <label for="">Grade</label>
                            <input type="text" class="form-control" name="graderumahsakit">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" class="form-control" name="emailrumahsakit">
                        </div>
                        <div class="form-group">
                            <label for="">Phone Number</label>
                            <input type="number" class="form-control" name="telprumahsakit">
                        </div>
                        <div class="form-group">
                            <label for="">Address</label>
                            <input type="text" class="form-control" name="addressrumahsakit">
                        </div>
                        <div class="form-group">
                            <label for="">Photo</label>
                            <input type="file" class="form-control" name="photo">
                        </div>
                        <button class="btn btn-primary" name="save">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
    if (isset($_POST['save'])) {
    $nama = $_FILES['photo']['name'];
    $lokasi = $_FILES['photo']['tmp_name'];
    move_uploaded_file($lokasi, "../../imgrs/".$nama);
    $koneksi->query("INSERT INTO datarumahsakit
    (id_rumahsakit, nama, grade, email, notelprs, alamat, foto) 
    VALUES ('$_POST[idrumahsakit]', '$_POST[namarumahsakit]', '$_POST[graderumahsakit]', '$_POST[emailrumahsakit]', '$_POST[telprumahsakit]', '$_POST[addressrumahsakit]', '$nama')");
   
    echo "<div class='alert alert-info'>Data Tersimpan</div>";
    echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=hospitals'>";
    }
?>