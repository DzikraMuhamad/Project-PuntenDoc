<?php 
$koneksi = new mysqli("localhost", "root", "", "puntendoc");
if (!isset($_SESSION)) {
        session_start();
    } else {
        $id = $_SESSION['id'];
        $result = mysqli_query($conn, "SELECT * FROM admin WHERE id = '$id' ");
        $row = mysqli_fetch_assoc($result);
    }
$usernameku = $_SESSION['admin']['username'];
$passwordku = $_SESSION['admin']['password'];
$namaku = $_SESSION['admin']['fullname'];
$fotoku = $_SESSION['admin']['foto'];
$notelpku = $_SESSION['admin']['notelp'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/profileadmin.css">
    <script src="https://kit.fontawesome.com/6e36a10e53.js" crossorigin="anonymous"></script>
    <title>My Profile</title>
</head>
<body>
    <header>
        <div class="text-box">
            <h1 id="title">My Profile</h1><hr>
            <p id="description">~Admin Profile~</p>
        </div>
        </header>
            <div class="container">
                <a href="index.php"><i class="fa-solid fa-house-user"></i></a>
                <form id="survey-form" method="post">
                    <div class="labels">
                    <label id="name-label">* Fullname</label></div>
                    <div class="input-tab">
                    <input class="input-field" type="text" id="name" name="fullname" placeholder="Enter Your Name" value="<?php echo $namaku ?>" required autofocus></div>

                    <div class="labels">
                    <label id="email-label">* Phone Number</label></div>
                    <div class="input-tab">
                    <input class="input-field" type="number" id="email" name="notelp" placeholder="Enter Your Phone Number" value="<?php echo $notelpku ?>" required></div>

                    <div class="labels">
                    <label id="number-label">* Email</label></div>
                    <div class="input-tab">
                    <input class="input-field" type="email" id="number" name="username" min="1" max="120" placeholder="Enter Your Email" value="<?php echo $usernameku ?>" required></div>

                    <div class="labels">
                    <label id="number-label">* Password</label></div>
                    <div class="input-tab">
                    <input class="input-field" type="password" name="password" min="1" max="120" placeholder="Enter Your Password" value="<?php echo $passwordku ?>" required></div>

                    <div class="labels">
                        <img src="../../imgadmin/<?php echo $fotoku ?>" alt="">
                    <label id="number-label">Change Photo</label></div>
                    <div class="input-tab">
                    <input class="input-field" type="file" name="foto" min="1" max="120"></div>
                </div>
                    <div class="btn">
                    <button id="submit" name="submit" type="submit">Submit</button>
                    </div>
                </form>
            </div>
                    <?php 
                    if (isset($_POST['submit'])) {
                        $namafoto = $_FILES['foto']['name'];
                        $lokasifoto = $_FILES['foto']['tmp_name'];
                        // jika foto di rubah
                        if (!empty($lokasifoto)) {
                            move_uploaded_file($lokasifoto, "../../imgadmin/$namafoto");
                            $koneksi->query("UPDATE admin SET fullname='$_POST[fullname]', notelp='$_POST[notelp]',
                            username='$_POST[username]', password='$_POST[password]', 
                            foto='$namafoto' WHERE id_admin='$_SESSION[admin][id_admin]'");
                        } else {
                            $koneksi->query("UPDATE admin SET fullname='$_POST[fullname]', notelp='$_POST[notelp]',
                            username='$_POST[username]', password='$_POST[password]', 
                            WHERE id_admin='$_SESSION[admin][id_admin]'");
                        }
                        echo "<script>alert('Data Admin telah diubah');</script>";
                        echo "<script>location='index.php';</script>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>