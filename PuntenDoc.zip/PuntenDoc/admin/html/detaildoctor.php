<div class="col-lg-20 mb-4 order-0">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="">
                        <div class="card-body">
                          <h5 class="card-title text-primary">Doctor Data</h5>
                          <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Photo</th>
                                        <th>Id_Doctor</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Specialist Doctor</th>
                                        <th>Email</th>
                                        <th>Address</th>
                                        <th>Phone Number</th>
                                        <th>Gender</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $ambil=$koneksi->query("SELECT * FROM datadoctor"); ?>
                                    <?php while($pecah = $ambil->fetch_assoc()){ ?>
                                    <tr>
                                        <td><img src="../img/<?php echo $pecah['foto']; ?>" width="100"></td>
                                        <td><?php echo $pecah['id_doctor']; ?></td>
                                        <td><?php echo $pecah['fname']; ?></td>
                                        <td><?php echo $pecah['lname']; ?></td>
                                        <td><?php echo $pecah['spcdokter']; ?></td>
                                        <td><?php echo $pecah['email']; ?></td>
                                        <td><?php echo $pecah['alamat']; ?></td>
                                        <td><?php echo $pecah['notelp']; ?></td>
                                        <td><?php echo $pecah['jkelamin']; ?></td>
                                        <td>
                                            <a href="delete.php" class="btn-info btn">Deatil</a>
                                            <a href="delete.php" class="btn-danger btn">Delete</a>
                                            <a href="modify.php" class="btn btn-warning">Modify</a>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="../assets/img/illustrations/man-with-laptop-light.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>