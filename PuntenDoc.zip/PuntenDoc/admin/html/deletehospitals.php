<?php
$ambil = $koneksi->query("SELECT * FROM datarumahsakit WHERE id_rumahsakit='$_GET[id]'");
$pecah = $ambil->fetch_assoc();
// $fotodoctor = $pecah['photo'];
// if (file_exists("../img/$fotodoctor")) {
//     unlink("../img/$fotodoctor");
// }
$koneksi->query("DELETE FROM datarumahsakit WHERE id_rumahsakit='$_GET[id]'");
echo "<script>alert('Rumah Sakit Terhapus');</script>";
echo "<script>location='index.php?halaman=hospitals';</script>";
?>