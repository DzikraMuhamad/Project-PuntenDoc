
        <div id="page-wrapper" >
            <div id="page-inner">
                <?php
                if (isset($_GET['halaman']))
                {
                    if ($_GET['halaman']=="product")
                    {
                        include 'product.php';
                    }
                    elseif ($_GET['halaman']=='pemesanan')
                    {
                        include 'pemesanan.php';
                    }
                    elseif ($_GET['halaman']=='customer')
                    {
                        include 'customer.php';
                    }
                    elseif ($_GET['halaman']=='transaksi')
                    {
                        include 'transaksi.php';
                    }
                    elseif ($_GET['halaman']=='pengiriman')
                    {
                        include 'pengiriman.php';
                    }
                    elseif ($_GET['halaman']=='detail')
                    {
                        include 'detail.php';
                    }
                    elseif ($_GET['halaman']=="addproduct")
                    {
                        include 'addproduct.php';
                    }
                    elseif ($_GET['halaman']=="deleteproduct")
                    {
                        include 'deleteproduct.php';
                    } 
                    elseif ($_GET['halaman']=="changeproduct")
                    {
                        include 'changeproduct.php';
                    }
                }
                else {
                    include 'home.php';
                }
                ?>