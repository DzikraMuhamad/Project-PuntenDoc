<div class="col-lg-20 mb-4 order-0">
                <div class="card">
                    <div class="d-flex align-items-end row">
                        <div class="">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Client Data</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID Client</th>
                                        <th>Fullname</th>
                                        <th>NIK</th>
                                        <th>Phone Number</th>
                                        <th>Email</th>
                                        <th>Gender</th>
                                        <th>Address</th>
                                        <th>Blood Group</th>
                                        <th>Weight</th>
                                        <th>Height</th>
                                        <th>Photo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $ambil=$koneksi->query("SELECT * FROM dataclient WHERE id_client='$_GET[id]'");
                                    $pecah = $ambil->fetch_assoc() 
                                    ?>
                                    <tr>
                                        <td><?php echo $pecah['id_client']; ?></td>
                                        <td><?php echo $pecah['namalengkap']; ?></td>
                                        <td><?php echo $pecah['nik']; ?></td>
                                        <td><?php echo $pecah['notelp']; ?></td>
                                        <td><?php echo $pecah['email']; ?></td>
                                        <td><?php echo $pecah['jkelamin']; ?></td>
                                        <td><?php echo $pecah['alamat']; ?></td>
                                        <td><?php echo $pecah['gdarah']; ?></td>
                                        <td><?php echo $pecah['bbadan']; ?></td>
                                        <td><?php echo $pecah['tbadan']; ?></td>
                                        <td><img src="../img/<?php echo $pecah['foto']; ?>" width="100"></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="../assets/img/illustrations/man-with-laptop-light.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>