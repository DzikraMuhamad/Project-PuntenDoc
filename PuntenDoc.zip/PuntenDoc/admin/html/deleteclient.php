<?php
$ambil = $koneksi->query("SELECT * FROM dataclient WHERE id_client='$_GET[id]'");
$pecah = $ambil->fetch_assoc();
// $fotodoctor = $pecah['photo'];
// if (file_exists("../img/$fotodoctor")) {
//     unlink("../img/$fotodoctor");
// }
$koneksi->query("DELETE FROM dataclient WHERE id_client='$_GET[id]'");
echo "<script>alert('Client Terhapus');</script>";
echo "<script>location='index.php?halaman=client';</script>";
?>