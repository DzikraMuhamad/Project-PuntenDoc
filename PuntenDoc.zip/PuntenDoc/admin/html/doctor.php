<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello, world!</title>
    <style>
      .popup {
        width: 100%;
        height: 100vh;
        background-color: rgba(0, 0, 0, .8);
        position: fixed;
        top: 0;
        left: 0;

        opacity: 0;
        visibility: hidden;
        transition: all .3s;
      }
      .popup__content{
        width: 50%;
        background-color: #fff;
        box-shadow: 0 20px 40px rgba(0, 0, 0, .2);
        position: absolute;
        margin-top: 100px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(.25);

        opacity: 0;
        transition: all .5s .1s;
      }
      .popup__img {
        display: flex;
        width: 100%;
        margin-bottom: 30px;
      }
      .popup__img img {
        display: block;
        width: 100%;
      }
      .popup__header {
        text-align: center;
        text-transform: uppercase;
        color: #555;
        margin-bottom: 36px;
      }
      .popup__header h1 {
        font-size: 30px;
        margin-bottom: 20px;
      }
      .popup__header h2 {
        font-size: 20px;
      }
      .popup__text{
        padding: 0 36px;
        line-height: 1.4;
      }
      #popup:target {
        opacity: 1;
        visibility: visible;
      }
      #popup:target .popup__content {
        opacity: 1;
        transform: translate(-50%, -50%) scale(1);
      }
      .popup__close:link, .popup__close:visited {
        position: absolute;
        top: 12px;
        right: 20px;
        text-decoration: none;
        color: #000;
        font-size: 30px;
        display: inline-block;
        line-height: 1;
        transition: all .3s;
      }
      .popup__close:hover, .popup__close:active {
        color: #555;
      }
    </style>
  </head>
  <body>
    <section class="tabelku">
      <div class="col-lg-11 mb-4 order-0" style="margin: auto;">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="">
                        <div class="card-body">
                          <h5 class="card-title text-primary">Doctor Data</h5>
                          <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <!-- <th>Id_Doctor</th> -->
                                        <th>NIK</th>
                                        <th>Full Name</th>
                                        <!-- <th>Last Name</th> -->
                                        <th>Specialist Doctor</th>
                                        <th>Email</th>
                                        <!-- <th>Address</th> -->
                                        <th>Phone Number</th>
                                        <th>Gender</th>
                                        <th>Photo</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor=1 ?>
                                    <?php $ambil=$koneksi->query("SELECT * FROM datadoctor"); ?>
                                    <?php while($pecah = $ambil->fetch_assoc()){ ?>
                                    <tr>
                                        <td><?php echo $nomor; ?></td>
                                        <td><?php echo $pecah['nik']; ?></td>
                                        <td><?php echo $pecah['fullname']; ?></td>
                                        <td><?php echo $pecah['spcdokter']; ?></td>
                                        <td><?php echo $pecah['email']; ?></td>
                                        <td><?php echo $pecah['notelp']; ?></td>
                                        <td><?php echo $pecah['jkelamin']; ?></td>
                                        <td>
                                          <img src="../../imgdoc/<?php echo $pecah['foto']; ?>" width="50">
                                        <td>
                                            <a href="#popup" class="btn-info btn" style="width: 55px; height:30px; font-size: 12px; padding: 5px;">Detail</a>
                                            <a href="index.php?halaman=deletedoctor&id=<?php echo $pecah['id_doctor']; ?>" class="btn-danger btn" style="width: 55px; height:30px; font-size: 12px; padding: 5px;">Delete</a>
                                            <a href="index.php?halaman=changedoctor&id=<?php echo $pecah['id_doctor']; ?>" class="btn btn-warning" style="width: 55px; height:30px; font-size: 12px; padding: 5px;">Modify</a>
                                        </td>
                                    </tr>
                                    <?php $nomor++; ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <a href="index.php?halaman=adddoctor" class="btn btn-primary">Add Doctor</a>
                        </div>
                      </div>
                      <div class="col-sm-5 text-center text-sm-left">
                        <div class="card-body pb-0 px-0 px-md-4">
                          <img
                            src="../assets/img/illustrations/man-with-laptop-light.png"
                            height="140"
                            alt="View Badge User"
                            data-app-dark-img="illustrations/man-with-laptop-dark.png"
                            data-app-light-img="illustrations/man-with-laptop-light.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
    </section>
    <div class="popup" id="popup">
      <div class="popup__content">
        <?php $ambil=$koneksi->query("SELECT * FROM datadoctor"); ?>
        <?php while($pecah = $ambil->fetch_assoc()){ ?>
        <div class="popup__img">
          <img src="" alt="doctorku">
        </div>
        <a href="#" class="popup__close">&times;</a>
        <div class="popup__header">
          <h1>Name : <?php echo $pecah['fullname']; ?></h1>
          <h2>Specialist Doctor : <?php echo $pecah['spcdokter']; ?></h2>
        </div>
        <div class="popup__text">
          <div class="card" style="width: 300px; text-align:center; margin:auto;">
            <ul class="list-group list-group-flush">
              <li class="list-group-item">ID Doctor : <?php echo $pecah['id_doctor']; ?></li>
              <li class="list-group-item">Email : <?php echo $pecah['email']; ?></li>
              <li class="list-group-item">Phone Number : <?php echo $pecah['notelp']; ?></li>
              <li class="list-group-item">Gender : <?php echo $pecah['jkelamin']; ?></li>
              <li class="list-group-item">Address : <?php echo $pecah['alamat']; ?></li>
            </ul>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </body>
</html>
