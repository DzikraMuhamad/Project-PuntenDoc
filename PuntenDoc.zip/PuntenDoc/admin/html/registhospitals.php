<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <section class="detailpembayaran">
        <div class="col-lg-11 mb-4 order-0" style="margin: auto;">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Registration Patient</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>ID REgistratin</th>
                                        <th>ID Client</th>
                                        <th>Fulllname</th>
                                        <th>ID Hospital</th>
                                        <th>Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor=1 ?>
                                    <?php $ambil=$koneksi->query("SELECT * FROM dataregis"); ?>
                                    <?php while($pecah = $ambil->fetch_assoc()){ ?>
                                    <tr>
                                        <td><?php echo $nomor; ?></td>
                                        <td><?php echo $pecah['id_regis']; ?></td>
                                        <td><?php echo $pecah['id_client']; ?></td>
                                        <td><?php echo $pecah['namalengkap']; ?></td>
                                        <td><?php echo $pecah['id_rumahsakit']; ?></td>
                                        <td><?php echo $pecah['namars']; ?></td>
                                    </tr>
                                    <?php $nomor++; ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <a href="index.php?halaman=addregisthospitals" class="btn btn-primary">Add Registration</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>