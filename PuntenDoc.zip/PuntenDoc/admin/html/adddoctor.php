<div class="col-lg-11 mb-4 order-0" style="margin: auto;">
    <div class="card">
        <div class="d-flex align-items-end row">
            <div class="">
                <div class="card-body">
                    <h5 class="card-title text-primary">Add Doctor</h5>
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">NIK</label>
                            <input type="number" class="form-control" name="nikdoctor">
                        </div>
                        <div class="form-group">
                            <label for="">Full Name</label>
                            <input type="text" class="form-control" name="firstname">
                        <div class="form-group">
                            <label for="">Specialist Doctor</label>
                            <input type="text" class="form-control" name="spclstdoctor">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" class="form-control" name="emaildoctor">
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="text" class="form-control" name="passdoctor">
                        </div>
                        <div class="form-group">
                            <label for="">Address</label>
                            <input type="text" class="form-control" name="addressdoctor">
                        </div>
                        <div class="form-group">
                            <label for="">Phone Number</label>
                            <input type="number" class="form-control" name="phonenumber">
                        </div>
                        <div class="form-group">
                            <label for="">Gender</label>
                            <input type="text" class="form-control" name="genderdoctor">
                        </div>
                        <div class="form-group">
                            <label for="">Photo</label>
                            <input type="file" class="form-control" name="foto">
                        </div>
                        <button class="btn btn-primary" name="save">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
    if (isset($_POST['save'])) {
    $nama = $_FILES['foto']['name'];
    $lokasi = $_FILES['foto']['tmp_name'];
    move_uploaded_file($lokasi, "../../imgdoc/".$nama);
    $koneksi->query("INSERT INTO datadoctor
    (nik, fullname, spcdokter, email, password, alamat, notelp, jkelamin, foto) 
    VALUES('$_POST[nikdoctor]', '$_POST[firstname]', '$_POST[spclstdoctor]', '$_POST[emaildoctor]', '$_POST[passdoctor]', '$_POST[addressdoctor]', '$_POST[phonenumber]', '$_POST[genderdoctor]', '$nama')");

    echo "<div class='alert alert-info'>Data Tersimpan</div>";
    echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=doctor'>";
    }
?>