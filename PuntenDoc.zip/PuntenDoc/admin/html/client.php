<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <section class="tabelku">
        <div class="col-lg-11 mb-4 order-0" style="margin: auto;">
            <div class="card">
                <div class="d-flex align-items-end row">
                    <div class="">
                        <div class="card-body">
                            <h5 class="card-title text-primary">Client Data</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Client Name</th>
                                        <th>Email</th>
                                        <th>Phone Number</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $nomor=1 ?>
                                    <?php $ambil=$koneksi->query("SELECT * FROM dataclient"); ?>
                                    <?php while($pecah = $ambil->fetch_assoc()){ ?>
                                    <tr>
                                        <td><?php echo $nomor; ?></td>
                                        <td><?php echo $pecah['namalengkap']; ?></td>
                                        <td><?php echo $pecah['email']; ?></td>
                                        <td><?php echo $pecah['notelp']; ?></td>
                                        <td>
                                            <a href="index.php?halaman=detailclient&id=<?php echo $pecah['id_client']; ?>" class="btn-info btn" style="width: 50px; height:30px; font-size: 12px; padding: 5px;">Detail</a>
                                            <a href="index.php?halaman=deleteclient&id=<?php echo $pecah['id_client']; ?>" class="btn-danger btn" style="width: 50px; height:30px; font-size: 12px; padding: 5px;">Delete</a>
                                        </td>
                                    </tr>
                                    <?php $nomor++; ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>