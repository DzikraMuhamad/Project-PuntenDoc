<div class="col-lg-11 mb-4 order-0" style="margin: auto;">
    <div class="card">
        <div class="d-flex align-items-end row">
            <div class="">
                <div class="card-body">
                    <h5 class="card-title text-primary">Modify Doctor</h5>
                    <?php 
                    $ambil = $koneksi->query("SELECT * FROM datadoctor WHERE id_doctor='$_GET[id]'");
                    $pecah = $ambil->fetch_assoc();
                    echo "<pre>";
                    print_r($pecah);
                    echo "</pre>";
                    ?>
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">ID Doctor</label>
                            <input type="number" class="form-control" name="iddoctor" value="<?php echo $pecah['id_doctor']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">NIK</label>
                            <input type="number" class="form-control" name="nikdoctor" value="<?php echo $pecah['nik']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Full Name</label>
                            <input type="text" class="form-control" name="firstname" value="<?php echo $pecah['fullname']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Specialist Doctor</label>
                            <input type="text" class="form-control" name="spclstdoctor" value="<?php echo $pecah['spcdokter']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="text" class="form-control" name="emaildoctor" value="<?php echo $pecah['email']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="text" class="form-control" name="passdoctor" value="<?php echo $pecah['password']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Address</label>
                            <input type="text" class="form-control" name="addressdoctor" value="<?php echo $pecah['alamat']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Phone Number</label>
                            <input type="number" class="form-control" name="phonenumber" value="<?php echo $pecah['notelp']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Gender</label>
                            <input type="text" class="form-control" name="genderdoctor" value="<?php echo $pecah['jkelamin']; ?>">
                        </div>
                        <div class="form_group">
                            <img src="../../imgddoc/<?php echo $pecah['foto'] ?>" width="100">
                        </div>
                        <div class="form-group">
                            <label>Change Photo</label>
                            <input type="file" name="foto" class="form-control">
                        </div>
                        <button class="btn btn-primary" name="change">Change</button>
                    </form>
                    <?php 
                    if (isset($_POST['change'])) {
                        $namafoto = $_FILES['foto']['name'];
                        $lokasifoto = $_FILES['foto']['tmp_name'];
                        // jika foto di rubah
                        if (!empty($lokasifoto)) {
                            move_uploaded_file($lokasifoto, "../../imgdoc/$namafoto");
                            $koneksi->query("UPDATE datadoctor SET id_doctor='$_POST[iddoctor]', nik='$_POST[nikdoctor]', fullname='$_POST[firstname]',
                            spcdokter='$_POST[spclstdoctor]', email='$_POST[emaildoctor]', password='$_POST[passdoctor]',
                            alamat='$_POST[addressdoctor]', jkelamin='$_POST[genderdoctor]', notelp='$_POST[phonenumber]', 
                            foto='$namafoto' WHERE id_doctor='$_GET[id]'");
                        } else {
                            $koneksi->query("UPDATE datadoctor SET nik='$_POST[nikdoctor]', fullname='$_POST[firstname]', 
                            spcdokter='$_POST[spclstdoctor]', email='$_POST[emaildoctor]', 
                            alamat='$_POST[addressdoctor]', jkelamin='$_POST[genderdoctor]', notelp='$_POST[phonenumber]'
                            WHERE id_doctor='$_GET[id]'");
                        }
                        echo "<script>alert('Data Doctor telah diubah');</script>";
                        echo "<script>location='index.php?halaman=doctor';</script>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>