<div class="col-lg-11 mb-4 order-0" style="margin: auto;">
    <div class="card">
        <div class="d-flex align-items-end row">
            <div class="">
                <div class="card-body">
                    <h5 class="card-title text-primary">Registration Hospital</h5>
                    <?php 
                    $ambil = $koneksi->query("SELECT * FROM registrasipasienrumahsakit");
                    $pecah = $ambil->fetch_assoc();
                    ?>
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">ID Patient</label>
                            <input type="number" class="form-control" name="id_client">
                        </div>
                        <div class="form-group">
                            <label for="">Name Patient</label>
                            <input type="text" class="form-control" name="fullname">
                        <div class="form-group">
                            <label for="">NIK</label>
                            <input type="number" class="form-control" name="nik">
                        </div>
                        <div class="form-group">
                            <label for="">ID Hospital</label>
                            <input type="number" class="form-control" name="id_rumahsakit">
                        </div>
                        <div class="form-group">
                            <label for="">Hospital</label>
                            <input type="text" class="form-control" name="namars">
                        </div>
                        <div class="form-group">
                            <label for="">Appointment</label>
                            <input type="text" class="form-control" name="appointment">
                        </div>
                        <div class="form-group">
                            <label for="">Date</label>
                            <input type="date" class="form-control" name="appointment">
                        </div>
                        <button class="btn btn-primary" name="post">Post</button>
                    </form>
                    <?php 
                    if (isset($_POST['post'])) {
                        $koneksi->query("INSERT INTO registrasipasienrumahsakit (id_client, fullname, nik, id_rumahsakit, namars, appointment, tanggal) VALUES ('$_POST[id_client]', '$_POST[fullname]', '$_POST[nik]', '$_POST[id_rumahsakit]', '$_POST[namars]', '$_POST[appointment]', '$_POST[tanggal]')");
                        echo "<script>alert('Data Berhasil Diinsert');</script>";
                        echo "<script>location='index.php?halaman=regishosTpitals';</script>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>